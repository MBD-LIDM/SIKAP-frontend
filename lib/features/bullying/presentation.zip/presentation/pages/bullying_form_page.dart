import 'package:flutter/material.dart';
import 'package:sikap/features/bullying/data/repositories/bullying_repository.dart';
import 'package:sikap/core/network/api_client.dart';
import 'package:sikap/core/network/auth_header_provider.dart';

class BullyingFormPage extends StatefulWidget {
  final String? bullyingId; // null for create, not null for edit

  const BullyingFormPage({
    super.key,
    this.bullyingId,
  });

  @override
  State<BullyingFormPage> createState() => _BullyingFormPageState();
}

class _BullyingFormPageState extends State<BullyingFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  String _selectedType = 'verbal';
  String _selectedSeverity = 'medium';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // Bukti bahwa page ini aktif
    print("[DEBUG] BullyingFormPage mounted. bullyingId=${widget.bullyingId}");
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _submitForm() async {
    print("[DEBUG] Submit pressed");
    if (!_formKey.currentState!.validate()) {
      print("[DEBUG] Form invalid: title/description kosong");
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Form tidak valid. Isi judul & deskripsi minimal."),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    final repo = BullyingRepository(
      apiClient: ApiClient(),
      auth: AuthHeaderProvider(
        // TODO: ganti dengan mekanisme token sebenarnya (SharedPreferences/secure storage)
        loadUserToken: () async => null,
        loadGuestToken: () async => null,
      ),
    );

    final data = {
      "title": _titleController.text.trim(),
      "description": _descriptionController.text.trim(),
      // NOTE: sesuaikan dengan BE kamu. Untuk uji koneksi bisa pakai 1 dulu
      "incident_type_id": 1,
      "type": _selectedType,
      "severity": _selectedSeverity,
      "confirm_truth": true,
    };

    try {
      print("[DEBUG] Sending POST to /api/bullying/report/ with data=$data");
      final res = await repo.createBullyingReport(data, asGuest: true);
      print("[DEBUG] Response received: ${res.data}");

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Laporan berhasil dikirim 🎉"),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
    } catch (e, st) {
      print("[ERROR] Failed to submit report: $e");
      print(st);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Gagal mengirim laporan: $e"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text(widget.bullyingId == null ? 'Laporkan Bullying' : 'Edit Laporan'),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF7F55B1), // Purple
              Color(0xFFFFDBB6), // Light peach
            ],
            stops: [0.76, 1.0],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Judul Laporan',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Judul tidak boleh kosong';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 4,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Deskripsi tidak boleh kosong';
                    }
                    if (value.trim().length < 10) {
                      return 'Deskripsi minimal 10 karakter';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedType,
                  decoration: const InputDecoration(
                    labelText: 'Jenis Bullying',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'verbal', child: Text('Verbal')),
                    DropdownMenuItem(value: 'physical', child: Text('Fisik')),
                    DropdownMenuItem(value: 'cyber', child: Text('Cyber')),
                    DropdownMenuItem(value: 'social', child: Text('Sosial')),
                    DropdownMenuItem(value: 'sexual', child: Text('Seksual')),
                    DropdownMenuItem(value: 'other', child: Text('Lainnya')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedType = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedSeverity,
                  decoration: const InputDecoration(
                    labelText: 'Tingkat Keparahan',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'low', child: Text('Rendah')),
                    DropdownMenuItem(value: 'medium', child: Text('Sedang')),
                    DropdownMenuItem(value: 'high', child: Text('Tinggi')),
                    DropdownMenuItem(value: 'critical', child: Text('Kritis')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedSeverity = value!;
                    });
                  },
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading ? null : _submitForm,
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(widget.bullyingId == null
                          ? 'Kirim Laporan'
                          : 'Update Laporan'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
