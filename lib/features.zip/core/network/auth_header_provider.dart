import 'api_exception.dart';
typedef TokenLoader = Future<String?> Function();
typedef GuestLoader = Future<String?> Function();

class AuthHeaderProvider {
  final TokenLoader loadUserToken;
  final GuestLoader loadGuestToken;

  const AuthHeaderProvider({
    required this.loadUserToken,
    required this.loadGuestToken,
  });

  Future<Map<String, String>> build({bool asGuest = false}) async {
    final headers = <String, String>{};

    if (asGuest) {
      final guest = await loadGuestToken();
      if (guest == null || guest.isEmpty) {
        // Biar ketahuan jelas di UI: kenapa 401
        throw ApiException(message: 'Missing guest token', code: 401);
      }
      headers['X-Guest-Token'] = guest;
      return headers;
    }

    final token = await loadUserToken();
    if (token == null || token.isEmpty) {
      throw ApiException(message: 'Missing user token', code: 401);
    }
    headers['Authorization'] = 'Bearer $token';
    return headers;
  }
}
