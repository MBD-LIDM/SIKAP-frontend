// lib/core/network/auth_header_provider.dart
// FIX: header aman walau token kosong.

typedef AsyncStr = Future<String?> Function();

class AuthHeaderProvider {
  final AsyncStr? loadUserToken;
  final AsyncStr? loadGuestToken;

  AuthHeaderProvider({this.loadUserToken, this.loadGuestToken});

  Future<Map<String, String>> buildHeaders({bool asGuest = false}) async {
    final headers = <String, String>{
      "Accept": "application/json",
      "Content-Type": "application/json",
    };
    if (asGuest) {
      final t = await (loadGuestToken?.call());
      if (t != null && t.isNotEmpty) {
        headers["X-Guest-Token"] = t;
      }
      return headers;
    }
    final bearer = await (loadUserToken?.call());
    if (bearer != null && bearer.isNotEmpty) {
      headers["Authorization"] = "Bearer $bearer";
    }
    return headers;
  }
}
