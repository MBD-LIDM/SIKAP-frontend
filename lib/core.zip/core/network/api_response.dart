class ApiResponse<T> {
  final T data;
  ApiResponse(this.data);
}
