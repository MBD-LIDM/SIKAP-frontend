// lib/core/auth/ensure_guest_auth.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../network/api_env.dart';
import '../network/api_exception.dart';

const storage = FlutterSecureStorage();

Future<void> ensureGuestAuthenticated() async {
  final existing = await storage.read(key: 'guest_token');
  if (existing != null && existing.isNotEmpty) return;

  final uri = Uri.parse('${ApiEnv.baseUrl}/api/accounts/guest/quick-login/');
  final resp = await http.post(uri, headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  });

  if (resp.statusCode < 200 || resp.statusCode >= 300) {
    throw ApiException(message: 'Guest quick-login gagal: ${resp.statusCode} ${resp.body}', code: resp.statusCode);
  }
  final decoded = jsonDecode(resp.body);
  if (decoded is! Map || decoded['success'] != true) {
    throw ApiException(message: 'Envelope tidak valid: ${resp.body}');
  }
  final data = decoded['data'] as Map<String, dynamic>;
  final token = data['guest_token'] as String?;
  final guestId = data['guest_id'];
  if (token == null || token.isEmpty || guestId == null) {
    throw ApiException(message: 'Guest token/ID tidak ada di respons');
  }

  await storage.write(key: 'guest_token', value: token);
  await storage.write(key: 'guest_id', value: guestId.toString());
  // debug
  // ignore: avoid_print
  print('[GUEST] stored token & id: $guestId');
}
