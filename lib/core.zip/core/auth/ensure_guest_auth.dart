// lib/core/auth/ensure_guest.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

import 'package:sikap/core/network/api_client.dart';
import 'package:sikap/core/network/api_exception.dart';

const _kGuestToken = 'guest_token';
const _kGuestId    = 'guest_id';
const _kSchoolCode = 'school_code';
const _kGrade      = 'grade';
const _kDeviceId   = 'device_id';

Future<bool> hasGuestToken() async {
  const s = FlutterSecureStorage();
  final t = await s.read(key: _kGuestToken);
  return t != null && t.isNotEmpty;
}

Future<void> clearGuestSession() async {
  const s = FlutterSecureStorage();
  await s.delete(key: _kGuestToken);
  await s.delete(key: _kGuestId);
}

Future<void> ensureGuestAuthenticated({
  String? schoolCode,
  String? grade,      // kalau BE butuh integer, kirim "grade_id": int.parse(grade!)
  String? deviceId,
}) async {
  const storage = FlutterSecureStorage();

  // Fast path
  final existing = await storage.read(key: _kGuestToken);
  if (existing != null && existing.isNotEmpty) return;

  // Lengkapi profil
  final sc = (schoolCode ?? (await storage.read(key: _kSchoolCode)) ?? '').trim();
  final gr = (grade      ?? (await storage.read(key: _kGrade))      ?? '').trim();
  final dvStored = await storage.read(key: _kDeviceId);
  final dv = (deviceId ?? dvStored ?? '').trim().isEmpty ? const Uuid().v4() : (deviceId ?? dvStored!) ;

  if (sc.isEmpty || gr.isEmpty || dv.isEmpty) {
    throw ApiException(
      message: "Profil belum lengkap.",
      code: 400,
      errors: {
        if (sc.isEmpty) 'school_code': ['required'],
        if (gr.isEmpty) 'grade': ['required'],
        if (dv.isEmpty) 'device_id': ['required'],
      },
    );
  }

  await storage.write(key: _kSchoolCode, value: sc);
  await storage.write(key: _kGrade, value: gr);
  await storage.write(key: _kDeviceId, value: dv);

  final api = ApiClient();

  // NOTE: kalau BE butuh integer:
  // final payload = {"school_code": sc, "grade_id": int.parse(gr), "device_id": dv};
  final payload = {"school_code": sc, "grade": gr, "device_id": dv};

  // Tetap expectEnvelope=false agar kita bisa “unwrap” sendiri bila ternyata enveloped.
  final resp = await api.post<Map<String, dynamic>>(
    "/api/accounts/student/quick-login/",
    payload,
    headers: const {
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    expectEnvelope: false,
    transform: (raw) => Map<String, dynamic>.from(raw as Map),
  );

  // ==== ROBUST UNWRAP ====
  // Terima dua kemungkinan bentuk:
  // 1) Enveloped: { success:true, message:"", data:{ guest_token, guest_id, ... } }
  // 2) Flat:      { guest_token, guest_id, ... }
  Map<String, dynamic> root = resp.data;
  Map<String, dynamic> body = root;

  // Kalau ada 'success' dan 'data' berbentuk Map → anggap enveloped
  if (root.containsKey('success') && root['data'] is Map) {
    body = Map<String, dynamic>.from(root['data'] as Map);
  }

  // Ambil token dengan beberapa alias umum
  final token = (body['guest_token'] ??
                 body['token'] ??
                 body['access_token'] ??
                 body['access']) as String?;

  // Ambil id dengan beberapa alias umum
  final dynamic rawId = (body['guest_id'] ??
                         body['id'] ??
                         (body['guest'] is Map ? (body['guest'] as Map)['id'] : null));

  if (token == null || token.isEmpty || rawId == null) {
    // Bantu debug: tampilkan kunci-kunci yang tersedia agar cepat tahu struktur nyata.
    final availableKeys = body.keys.join(', ');
    throw ApiException(
      message: "Guest token/ID tidak ada di respons BE.",
      code: 500,
      errors: {"available_keys": [availableKeys]},
    );
  }

  final guestId = (rawId is num) ? rawId.toInt() : int.tryParse(rawId.toString());
  if (token == null || token.isEmpty) {
  // Print specifically which field is missing or empty for easier debugging
  // ignore: avoid_print
  if (token == null) print('[GUEST] quick-login missing: token=null');
  // ignore: avoid_print
  if (token != null && token.isEmpty) print('[GUEST] quick-login missing: token=empty');
  // ignore: avoid_print


  await storage.write(key: _kGuestToken, value: token);
  await storage.write(key: _kGuestId, value: guestId.toString());

  // ignore: avoid_print
  print("[GUEST] stored guest_id=$guestId token=${token.substring(0, 8)}...");
}
}