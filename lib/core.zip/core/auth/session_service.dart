// lib/core/auth/session_service.dart
// FIX: simpan profil (school_code, grade, device_id), quick-login (tanpa envelope),
// persist guest_token & guest_id. Tambah error yang jelas.

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sikap/core/network/api_client.dart';
import 'package:sikap/core/network/api_exception.dart';

class SessionService {
  final _s = const FlutterSecureStorage();

  static const _kGuestToken = 'guest_token';
  static const _kGuestId    = 'guest_id';
  static const _kSchoolCode = 'school_code';
  static const _kGrade      = 'grade';
  static const _kDeviceId   = 'device_id';

  Future<void> saveProfile({
    required String schoolCode,
    required String grade,
    required String deviceId,
  }) async {
    await _s.write(key: _kSchoolCode, value: schoolCode);
    await _s.write(key: _kGrade, value: grade);
    await _s.write(key: _kDeviceId, value: deviceId);
  }

  Future<({String? schoolCode, String? grade, String? deviceId})> loadProfile() async {
    final sc = await _s.read(key: _kSchoolCode);
    final gr = await _s.read(key: _kGrade);
    final dv = await _s.read(key: _kDeviceId);
    return (schoolCode: sc, grade: gr, deviceId: dv);
  }

  Future<void> saveGuest(String token, int guestId) async {
    await _s.write(key: _kGuestToken, value: token);
    await _s.write(key: _kGuestId, value: guestId.toString());
  }

  Future<String?> loadGuestToken() => _s.read(key: _kGuestToken);
  Future<int?> loadGuestId() async {
    final v = await _s.read(key: _kGuestId);
    return v == null ? null : int.tryParse(v);
  }

  Future<void> clearGuest() async {
    await _s.delete(key: _kGuestToken);
    await _s.delete(key: _kGuestId);
  }

  /// Login tamu bila belum ada token.
  /// Throw ApiException (400) jika profil belum lengkap/valid.
  Future<bool> ensureGuest() async {
    final existing = await loadGuestToken();
    if (existing != null && existing.isNotEmpty) return true;

    final p = await loadProfile();
    final sc = (p.schoolCode ?? '').trim();
    final gr = (p.grade ?? '').trim();
    final dv = (p.deviceId ?? '').trim();

    if (sc.isEmpty || gr.isEmpty || dv.isEmpty) {
      throw ApiException(
        message: "Profil belum lengkap.",
        code: 400,
        errors: {
          if (sc.isEmpty) 'school_code': ['required'],
          if (gr.isEmpty) 'grade': ['required'],
          if (dv.isEmpty) 'device_id': ['required'],
        },
      );
    }

    final api = ApiClient();
    final res = await api.post<Map<String, dynamic>>(
      "/api/accounts/student/quick-login/",
      {"school_code": sc, "grade": gr, "device_id": dv},
      headers: const {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      expectEnvelope: false, // endpoint ini tidak memakai envelope
      transform: (raw) => Map<String, dynamic>.from(raw as Map),
    );

    final token = (res.data['guest_token'] ?? res.data['token']) as String?;
    final gid = res.data['guest_id'];
    if (token == null || token.isEmpty || gid == null) {
      throw ApiException(message: "Guest token/ID tidak ada di respons BE.", code: 500);
    }
    final guestId = (gid is num) ? gid.toInt() : int.parse(gid.toString());
    await saveGuest(token, guestId);

    // ignore: avoid_print
    print('[GUEST] stored guest_id=$guestId token=${token.substring(0, 8)}...');
    return true;
  }
}
