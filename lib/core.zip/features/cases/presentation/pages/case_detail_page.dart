import 'package:flutter/material.dart';
import 'case_confirmation_page.dart';

class CaseDetailPage extends StatelessWidget {
  const CaseDetailPage({
    super.key,
    required this.title,
    required this.status,
    required this.createdAt,
    required this.category,
    required this.description,
    required this.evidences,
    required this.anonymous,
    required this.confirmTruth,
  });

  final String title;
  final String status;
  final DateTime createdAt;
  final String category; // e.g., "Secara verbal"
  final String description;
  final List<String> evidences; // simple labels for now
  final bool anonymous;
  final bool confirmTruth;

  Color get statusColor {
    switch (status) {
      case 'Baru':
        return const Color(0xFF2196F3);
      case 'Diproses':
        return const Color(0xFFFF9800);
      case 'Selesai':
        return const Color(0xFF2E7D32);
      default:
        return Colors.grey;
    }
  }

  static String _formatDate(DateTime dt) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Kasus'),
        backgroundColor: const Color(0xFF7F55B1),
        foregroundColor: Colors.white,
      ),
      body: Container(
        color: const Color(0xFF7F55B1),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 12, offset: const Offset(0, 4)),
                        ],
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Status
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20)),
                            child: Text(status, style: TextStyle(color: statusColor, fontWeight: FontWeight.w700, fontSize: 12)),
                          ),
                          const SizedBox(height: 8),
                          // Title
                          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Colors.black87)),
                          const SizedBox(height: 12),
                          // Created at
                          Row(
                            children: [
                              const Icon(Icons.edit_calendar, size: 18, color: Colors.black45),
                              const SizedBox(width: 8),
                              Text(_formatDate(createdAt), style: const TextStyle(color: Colors.black45)),
                            ],
                          ),
                          const Divider(height: 32),
                          // Category (Step 1)
                          const Text('Kategori Bullying', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87)),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFE4B5),
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 2, offset: const Offset(0, 1)),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.record_voice_over, color: Color(0xFF7F55B1)),
                                const SizedBox(width: 8),
                                Text(category, style: const TextStyle(color: Colors.black87)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          // Description (Step 2)
                          const Text('Penjelasan', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87)),
                          const SizedBox(height: 8),
                          Text(description.isEmpty ? '-' : description),
                          const SizedBox(height: 16),
                          // Evidences (Step 3)
                          const Text('Bukti', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87)),
                          const SizedBox(height: 8),
                          if (evidences.isEmpty)
                            const Text('-', style: TextStyle(color: Colors.black54))
                          else
                            Column(
                              children: evidences
                                  .map((e) => Padding(
                                        padding: const EdgeInsets.only(bottom: 8),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [
                                            BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2)),
                                          ]),
                                          child: Row(
                                            children: [
                                              const Icon(Icons.insert_drive_file, color: Color(0xFF7F55B1)),
                                              const SizedBox(width: 8),
                                              Expanded(child: Text(e)),
                                            ],
                                          ),
                                        ),
                                      ))
                                  .toList(),
                            ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white)),
                        onPressed: () async {
                          final result = await Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => CaseConfirmationPage(caseTitle: title, action: 'tolak'),
                            ),
                          );
                          if (!context.mounted) return;
                          if (result != null) {
                            Navigator.of(context).pop(result);
                          }
                        },
                        child: const Text('Tolak'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFB678FF), foregroundColor: Colors.white),
                        onPressed: () async {
                          final result = await Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => CaseConfirmationPage(caseTitle: title, action: 'proses'),
                            ),
                          );
                          if (!context.mounted) return;
                          if (result != null) {
                            Navigator.of(context).pop(result);
                          }
                        },
                        child: const Text('Proses', style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


